import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:linked_scroll_controller/linked_scroll_controller.dart';
import 'package:mobiletrack_dispatch_flutter/components/left_drawer.dart';
import 'package:mobiletrack_dispatch_flutter/components/status_key.dart';
import 'package:mobiletrack_dispatch_flutter/constants/constants.dart';
import 'package:mobiletrack_dispatch_flutter/models/technician_model.dart';
import 'package:mobiletrack_dispatch_flutter/models/work_order_model.dart';
import 'package:mobiletrack_dispatch_flutter/providers/schedule_provider.dart';
import 'package:mobiletrack_dispatch_flutter/providers/settings_provider.dart';
import 'package:provider/provider.dart';

class MultiplicationTableCell extends StatelessWidget {
  final Color color;
  final Widget child;
  final double cellWidth;

  MultiplicationTableCell({
    required this.child,
    required this.color,
    required this.cellWidth,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: cellWidth,
      height: 50,
      //height: cellWidth,
      decoration: BoxDecoration(
        color: color,
        border: Border.all(
          color: Colors.black12,
          width: 1.0,
        ),
      ),
      alignment: Alignment.center,
      child: child,
    );
  }
}

class TableHead extends StatelessWidget {
  final ScrollController scrollController;
  final double cellWidth;

  final Widget title;
  final List<String> headerList;

  TableHead({
    required this.scrollController,
    required this.title,
    required this.cellWidth,
    required this.headerList,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      //height: cellWidth,
      height: 50,
      child: Row(
        children: [
          Container(width: cellWidth, child: title),
          Expanded(
            child: ListView(
              controller: scrollController,
              physics: ClampingScrollPhysics(),
              scrollDirection: Axis.horizontal,
              children: List.generate(headerList.length, (index) {
                return MultiplicationTableCell(
                  color: Colors.transparent,
                  child: Text(
                    headerList[index],
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                    textAlign: TextAlign.center,
                  ),
                  cellWidth: cellWidth,
                );
              }),
            ),
          ),
        ],
      ),
    );
  }
}

class TableBody extends StatefulWidget {
  final ScrollController scrollController;

  final List<TimelineRow> timelineRows;
  final List<DateTime> timeline;

  TableBody({
    required this.timeline,
    required this.scrollController,
    required this.timelineRows,
  });

  @override
  _TableBodyState createState() => _TableBodyState();
}

class _TableBodyState extends State<TableBody> {
  late LinkedScrollControllerGroup _controllers;
  late ScrollController _firstColumnController;
  late ScrollController _restColumnsController;

  late double cellWidth = 100.0;

  @override
  void initState() {
    super.initState();
    _controllers = LinkedScrollControllerGroup();
    _firstColumnController = _controllers.addAndGet();
    _restColumnsController = _controllers.addAndGet();
  }

  @override
  void dispose() {
    _firstColumnController.dispose();
    _restColumnsController.dispose();
    super.dispose();
  }

  Color getColorFromHex(String hexColor) {
    hexColor = hexColor.replaceAll("#", "");
    final Random random = Random();
    if (hexColor.length == 6) {
      hexColor = "FF" + hexColor;
    }
    if (hexColor.length == 8) {
      return Color(int.parse("0x$hexColor"));
    } else {
      return Color.fromRGBO(
          random.nextInt(255), random.nextInt(255), random.nextInt(255), 1);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        SizedBox(
          width: cellWidth,
          child: ListView(
            controller: _firstColumnController,
            physics: ClampingScrollPhysics(),
            children: List.generate(widget.timelineRows.length, (index) {
              Technician technician = widget.timelineRows[index].technician;

              return MultiplicationTableCell(
                color: getColorFromHex(technician.color),
                cellWidth: cellWidth,
                child: Text(
                  "${technician.firstName} ${technician.lastName}",
                  maxLines: 2,
                  textAlign: TextAlign.center,
                ),
              );
            }),
          ),
        ),
        Expanded(
          child: SingleChildScrollView(
            controller: widget.scrollController,
            scrollDirection: Axis.horizontal,
            physics: const ClampingScrollPhysics(),
            child: SizedBox(
              width: (widget.timeline.length) * cellWidth,
              child: ListView(
                  controller: _restColumnsController,
                  physics: const ClampingScrollPhysics(),
                  children: List.generate(widget.timelineRows.length, (y) {
                    return SizedBox(
                        width: (widget.timeline.length) * cellWidth,
                        height: 50,
                        child: Stack(
                            children: List.generate(
                                widget.timelineRows[y].workOrders.length, (x) {
                          WorkOrder workOrder =
                              widget.timelineRows[y].workOrders[0];

                          double startPosition = 0;
                          double endPosition = 100;

                          DateTime timeStart = widget.timeline.first;
                          DateTime timeEnd = widget.timeline.last;

                          double totalMinutes = widget.timeline.length * 60;

                          Duration differenceStart = timeStart
                              .difference(workOrder.startDate.toDate());
                          int minutesStart = differenceStart.inMinutes;

                          ///workOrder.startTime.minute;

                          if (minutesStart < 0) {
                            startPosition = 0;
                          } else {
                            startPosition = minutesStart / totalMinutes;
                          }

                          Duration differenceEnd =
                              timeEnd.difference(workOrder.endDate.toDate());
                          int minutesEnd = differenceEnd.inMinutes;

                          ///workOrder.startTime.minute;

                          if (minutesEnd > totalMinutes) {
                            endPosition = 100;
                          } else {
                            endPosition = (minutesEnd / totalMinutes) * -1;
                          }

                          Widget child = Container(
                            color: Colors.lightBlueAccent.withOpacity(0.5),
                            margin: EdgeInsets.symmetric(vertical: 1),
                            padding: EdgeInsets.symmetric(
                                vertical: 5, horizontal: 5),
                            //height: 50,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                    child: Text(
                                  workOrder.displayName,
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold),
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 1,
                                )),
                                SizedBox(
                                  height: 2,
                                ),
                                Container(
                                    child: Text(
                                  workOrder.description,
                                  //"total - $totalMinutes, minutesStart-$minutesStart, minutesEnd-$minutesEnd, start position-$startPosition, end position-$endPosition, start - ${workOrder.startTime.hour}:${workOrder.startTime.minute}, end - ${workOrder.endTime.hour}:${workOrder.endTime.minute}",
                                  style: TextStyle(fontSize: 12),
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 1,
                                )),
                              ],
                            ),
                          );

                          double totalWidth =
                              (widget.timeline.length) * cellWidth;

                          return Positioned(
                              top: 0,
                              left: startPosition,
                              right: totalWidth - (totalWidth * endPosition),
                              bottom: 0,
                              child: child);
                        })));
                  })) /*ListView(
                controller: _restColumnsController,
                physics: const ClampingScrollPhysics(),
                children: List.generate(widget.timelineRows.length, (y) {
                  return Row(
                    children: List.generate(widget.timeline.length, (x) {
                      //compare time

                      DateTime time = widget.timeline[x];
                      Widget child = Text("y-$y, x-$x"); //SizedBox();

                      WorkOrder? workOrder;
                      if (widget.timelineRows[y].workOrders.isNotEmpty) {
                        workOrder = widget.timelineRows[y].workOrders[0];

                        double startPosition = 0;
                        double endPosition = 100;

                        bool inTime = false;

                        if (workOrder.startDate.toDate().hour == time.hour) {
                          Duration differenceStart =
                              time.difference(workOrder.startDate.toDate());

                          int minutesStart = workOrder.startTime.minute;

                          if (minutesStart < 0) {
                            startPosition = 0;
                          } else {
                            startPosition = minutesStart / 60;
                          }

                          inTime = true;
                        }

                        if (workOrder.endDate.toDate().hour == time.hour) {
                          Duration differenceEnd =
                              time.difference(workOrder.endDate.toDate());

                          int minutesEnd = workOrder.endTime.minute;

                          if (minutesEnd > 60) {
                            endPosition = 100;
                          } else {
                            endPosition = (minutesEnd) / 60;
                          }

                          inTime = true;
                        }

                        print(
                            "y - $y, x - $x,inTime - $inTime, start - $startPosition, end - $endPosition, tech - ${widget.timelineRows[y].technician.firstName}, order - ${workOrder.displayName}, start - ${workOrder.startTime.hour}:${workOrder.startTime.minute}, end - ${workOrder.endTime.hour}:${workOrder.endTime.minute}");

                        if (inTime) {
                          child = Container(
                            margin: EdgeInsets.only(
                                left: cellWidth * startPosition,
                                right: cellWidth * endPosition),
                            color: Colors.lightBlueAccent,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                    child: Text(
                                  workOrder.displayName,
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold),
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 1,
                                )),
                                SizedBox(
                                  height: 2,
                                ),
                                Container(
                                    child: Text(
                                  workOrder.description,
                                  style: TextStyle(fontSize: 12),
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 1,
                                )),
                              ],
                            ),
                          );
                        }
                      }

                      return MultiplicationTableCell(
                        child: child,
                        cellWidth: cellWidth,
                        color: Colors.transparent,
                      );
                    }),
                  );
                }),
              )*/
              ,
            ),
          ),
        ),
      ],
    );
  }
}

class MultiplicationTable extends StatefulWidget {
  final List<DateTime> timeline;
  final List<TimelineRow> timelineRows;

  MultiplicationTable({required this.timeline, required this.timelineRows});

  @override
  _MultiplicationTableState createState() => _MultiplicationTableState();
}

class _MultiplicationTableState extends State<MultiplicationTable> {
  late LinkedScrollControllerGroup _controllers;
  late ScrollController _headController;
  late ScrollController _bodyController;

  DateFormat textFormatter = DateFormat('h a');

  @override
  void initState() {
    super.initState();
    _controllers = LinkedScrollControllerGroup();
    _headController = _controllers.addAndGet();
    _bodyController = _controllers.addAndGet();
  }

  @override
  void dispose() {
    _headController.dispose();
    _bodyController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        TableHead(
          scrollController: _headController,
          cellWidth: 100.0,
          headerList:
              widget.timeline.map((e) => "${textFormatter.format(e)}").toList(),
          title: Text(
            "Field Technicians",
            style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
            textAlign: TextAlign.center,
          ),
        ),
        Expanded(
          child: TableBody(
              scrollController: _bodyController,
              timeline: widget.timeline,
              timelineRows: widget.timelineRows),
        ),
      ],
    );
  }
}

class SchedulePage extends StatefulWidget {
  @override
  _ScheduleState createState() => _ScheduleState();
}

class _ScheduleState extends State<SchedulePage> {
  late ScheduleProvider scheduleProvider;
  late SettingsProvider settingsProvider;
  Timestamp startDate = Timestamp.now();
  bool subServiceOrders = false;
  DateTime selectedDate = DateTime.now();

  DateFormat dateFormatter = DateFormat('MMDDyy');
  DateFormat textFormatter = DateFormat('yMMMMd');

  bool fullTimeline = false;

  List<DateTime> get timeline =>
      fullTimeline ? fullTimelineList() : timelineList();

  List<DateTime> fullTimelineList() {
    DateTime dateTime = new DateTime(
      selectedDate.year,
      selectedDate.month,
      selectedDate.day,
      0,
      0,
    );
    return List.generate(24, (index) {
      dateTime = dateTime.add(Duration(hours: 1));
      return dateTime;
    });
  }

  List<DateTime> timelineList() {
    DateTime dateTime = new DateTime(
      selectedDate.year,
      selectedDate.month,
      selectedDate.day,
      5,
      1,
    );
    return List.generate(14, (index) {
      dateTime = dateTime.add(Duration(hours: 1));
      return dateTime;
    });
  }

  @override
  void initState() {
    super.initState();
    this.scheduleProvider =
        Provider.of<ScheduleProvider>(context, listen: false);
    this.settingsProvider =
        Provider.of<SettingsProvider>(context, listen: false);
    scheduleProvider.getTechnicians('hukills');
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    ScheduleProvider scheduleProvider = Provider.of<ScheduleProvider>(context);
    if (scheduleProvider.technicians.isNotEmpty && !subServiceOrders) {
      scheduleProvider.subServiceOrdersByDate('hukills', selectedDate);
      setState(() => subServiceOrders = true);
    }
  }

  void _incrementDate() {
    print('Increment Date!');
    var newDate = new DateTime(
        selectedDate.year, selectedDate.month, selectedDate.day + 1);
    setState(() => selectedDate = newDate);
    scheduleProvider.subServiceOrdersByDate('hukills', selectedDate);
  }

  void _decrementDate() {
    print('Decrement Date!');
    var newDate = new DateTime(
        selectedDate.year, selectedDate.month, selectedDate.day - 1);
    setState(() => selectedDate = newDate);
    scheduleProvider.subServiceOrdersByDate('hukills', selectedDate);
  }

  void _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: selectedDate,
        firstDate: DateTime(2000),
        lastDate: DateTime(2025));
    if (picked != null && picked != selectedDate) {
      setState(() => selectedDate = picked);
      scheduleProvider.subServiceOrdersByDate('hukills', selectedDate);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: AppTheme.greyBackground,
        appBar: AppBar(
          backgroundColor: AppTheme.green,
          title: Text('Service Requests'),
          leading: Builder(
            builder: (BuildContext context) {
              return IconButton(
                icon: const Icon(Icons.menu),
                onPressed: () {
                  Scaffold.of(context).openDrawer();
                },
              );
            },
          ),
          actions: [
            IconButton(icon: Icon(Icons.search), onPressed: () {}),
          ],
        ),
        drawer: Drawer(
          child: LeftDrawer(),
        ),
        body: Container(
            child: Column(mainAxisSize: MainAxisSize.max, children: [
          Container(
            padding: EdgeInsets.all(10),
            decoration: BoxDecoration(
                border: Border(
                    bottom: BorderSide(width: 1, color: Colors.grey[300]!))),
            width: double.infinity,
            child: Column(children: [
              Row(
                children: [
                  Expanded(
                      child: Row(
                    children: [
                      IconButton(
                          icon: Icon(Icons.date_range),
                          onPressed: () => _selectDate(context)),
                      Text(textFormatter.format(this.selectedDate)),
                    ],
                  )),
                  IconButton(
                    icon: Icon(Icons.chevron_left),
                    onPressed: () => _decrementDate(),
                  ),
                  IconButton(
                    icon: Icon(Icons.chevron_right),
                    onPressed: () => _incrementDate(),
                  ),
                ],
              ),
              Row(
                children: [
                  Expanded(
                      child: Row(children: [
                    InkWell(
                      child: Container(
                          height: 40,
                          width: 100,
                          decoration: BoxDecoration(
                            border:
                                Border.all(color: Colors.grey[300]!, width: 1),
                          ),
                          child: Row(
                            children: [
                              Container(
                                  height: double.infinity,
                                  width: 4,
                                  color: Colors.green),
                              Container(
                                  padding: EdgeInsets.all(10),
                                  child: Text('Status Key'))
                            ],
                          )),
                    )
                  ])),
                  Row(
                    children: [
                      InkWell(
                          onTap: () async {
                            setState(() {
                              fullTimeline = !fullTimeline;
                            });
                            await scheduleProvider.subServiceOrdersByDate(
                                "hukills", selectedDate);
                            setState(() {});
                          },
                          child: Container(
                              padding: EdgeInsets.all(5),
                              decoration: BoxDecoration(
                                border: Border.all(
                                    color: Colors.grey[400]!, width: 1),
                              ),
                              child: Icon(Icons.swap_horiz))),
                      SizedBox(width: 10),
                      Container(
                          padding: EdgeInsets.all(5),
                          decoration: BoxDecoration(
                            border:
                                Border.all(color: Colors.grey[400]!, width: 1),
                          ),
                          child: Icon(Icons.today)),
                      Container(
                          padding: EdgeInsets.all(5),
                          decoration: BoxDecoration(
                            border:
                                Border.all(color: Colors.grey[400]!, width: 1),
                          ),
                          child: Icon(Icons.event_note)),
                      Container(
                          padding: EdgeInsets.all(5),
                          decoration: BoxDecoration(
                            border:
                                Border.all(color: Colors.grey[400]!, width: 1),
                          ),
                          child: Icon(Icons.event)),
                    ],
                  )
                ],
              )
            ]),
          ),
          Expanded(
              child: MultiplicationTable(
            timeline: timeline,
            timelineRows: scheduleProvider.timelineRows,
          ))
        ])));

    /* return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth > 760) {
          return TabletLayout(selectDate: this._selectDate, selectedDate: this.selectedDate, incrementDate: this._incrementDate, decrementDate: this._decrementDate);
        } else {
          return PhoneLayout();
        }
      },
    );*/
  }
}

class TabletLayout extends StatefulWidget {
  final Function incrementDate;
  final Function decrementDate;
  final Function selectDate;
  final DateTime selectedDate;

  const TabletLayout(
      {Key? key,
      required this.selectDate,
      required this.selectedDate,
      required this.decrementDate,
      required this.incrementDate})
      : super(key: key);

  @override
  _TabletLayoutState createState() => _TabletLayoutState();
}

class _TabletLayoutState extends State<TabletLayout> {
  final ScrollController _scrollController =
      ScrollController(initialScrollOffset: 0);

  final List<Widget> timesHeader = List.generate(14, (index) {
    if (index + 6 > 12) {
      return Expanded(
          flex: 1,
          child: Center(
            child: Text(
              '${index + 6 - 12}PM',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
          ));
    }
    return Expanded(
        flex: 1,
        child: Center(
          child: Text(
            index + 6 == 12 ? '${index + 6}PM' : '${index + 6}AM',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
        ));
  });
  late ScheduleProvider scheduleProvider;
  late SettingsProvider settingsProvider;
  bool gotTechnicians = false;

  @override
  void initState() {
    super.initState();
    this.scheduleProvider =
        Provider.of<ScheduleProvider>(context, listen: false);
    this.settingsProvider =
        Provider.of<SettingsProvider>(context, listen: false);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // ScheduleProvider scheduleProvider = Provider.of<ScheduleProvider>(context, listen: true);
    // if(scheduleProvider.technicians.isNotEmpty && !gotTechnicians) {
    //   technicians = scheduleProvider.technicians;
    //   print('done?');
    // }
  }

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: AppTheme.greyBackground,
      appBar: AppBar(
        backgroundColor: AppTheme.green,
        title: Text('Service Requests'),
        leading: Builder(
          builder: (BuildContext context) {
            return IconButton(
              icon: const Icon(Icons.menu),
              onPressed: () {
                Scaffold.of(context).openDrawer();
              },
            );
          },
        ),
        actions: [
          IconButton(icon: Icon(Icons.search), onPressed: () {}),
        ],
      ),
      drawer: Drawer(
        child: LeftDrawer(),
      ),
      body: Container(
          width: size.width,
          height: size.height,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              NavBar(
                selectedDate: this.widget.selectedDate,
                selectDate: this.widget.selectDate,
                decrementDate: this.widget.decrementDate,
                incremenDate: this.widget.incrementDate,
              ),
              if (scheduleProvider.isLoading)
                Expanded(
                  child: Container(
                      width: double.infinity,
                      height: double.infinity,
                      child: Center(
                        child: CircularProgressIndicator(),
                      )),
                ),
              if (!scheduleProvider.isLoading)
                Expanded(
                  child: Container(
                      padding: EdgeInsets.all(20),
                      height: double.infinity,
                      width: double.infinity,
                      child: Container(
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.red, width: 1),
                          ),
                          child: Column(
                            children: [
                              TechRowHeader(timesHeader: timesHeader),
                              Expanded(
                                child: Container(
                                    height: double.infinity,
                                    width: double.infinity,
                                    decoration: BoxDecoration(
                                      border: Border.all(
                                          color: Colors.blue, width: 1),
                                    ),
                                    child: RawScrollbar(
                                      controller: _scrollController,
                                      isAlwaysShown: true,
                                      thumbColor: Colors.grey[700],
                                      radius: Radius.circular(10),
                                      thickness: 10,
                                      child: ListView.builder(
                                          controller: _scrollController,
                                          itemCount: scheduleProvider
                                              .schedule.rows.length,
                                          itemBuilder: (_, int index) {
                                            TechnicianRow row = scheduleProvider
                                                .schedule.rows[index];
                                            return TechRow(technicianRow: row);
                                          }),
                                    )),
                              )
                            ],
                          ))),
                )
            ],
          )),
    );
  }
}

class TechRow extends StatefulWidget {
  final TechnicianRow technicianRow;

  const TechRow({Key? key, required this.technicianRow}) : super(key: key);

  @override
  _TechRowState createState() => _TechRowState();
}

class _TechRowState extends State<TechRow> {
  int maxRows = 1;
  double rowHeight = 75.0;
  List<Widget> timeSlots = [];
  late SettingsProvider settingsProvider;

  @override
  void initState() {
    super.initState();
    settingsProvider = Provider.of<SettingsProvider>(context, listen: false);

    this.widget.technicianRow.timeSlots!.forEach((e) {
      // var numberOfThisWorkOrder = this.widget.technicianRow.timeSlots!.where((timeSlot) => timeSlot.workOrder?.id == e.workOrder?.id);

      if (e.workOrder == null) {
        timeSlots.add(Expanded(
            flex: 1,
            child: Container(
              width: double.infinity,
              height: double.infinity,
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border.all(color: Colors.red, width: 1),
              ),
            )));
      }

      if (e.workOrder != null) {
        var status = settingsProvider
            .localSettings['workOrderCustomStatusTypes']
            .singleWhere((status) => status['id'] == e.workOrder!.statusId);

        // get all the workorder, determine how many rows it takes up

        timeSlots.add(Expanded(
            flex: 1,
            child: Container(
                width: double.infinity,
                height: double.infinity,
                decoration: BoxDecoration(
                  color: Color(int.parse('0xFF${status['color']}')),
                  border: Border.all(color: Colors.red, width: 1),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      e.workOrder!.displayName,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    )
                  ],
                ))));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        height: rowHeight * maxRows,
        decoration: BoxDecoration(
          border: Border.all(color: Colors.black, width: 1),
        ),
        child: Column(
          children: [
            Expanded(
              child: ListView.builder(
                  physics: NeverScrollableScrollPhysics(),
                  itemCount: maxRows,
                  itemBuilder: (_, int index) {
                    return Container(
                        height: rowHeight,
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.black, width: 1),
                        ),
                        child: Row(
                          children: [
                            Expanded(
                                flex: 3,
                                child: Container(
                                    width: double.infinity,
                                    height: double.infinity,
                                    color: this.widget.technicianRow.color,
                                    child: Text(
                                        this.widget.technicianRow.techName))),
                            ...timeSlots
                          ],
                        ));
                  }),
            )
          ],
        ));
  }
}

class TechRowHeader extends StatelessWidget {
  final List<Widget> timesHeader;

  const TechRowHeader({Key? key, required this.timesHeader}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    return Container(
      decoration: BoxDecoration(
          border:
              Border(bottom: BorderSide(width: 1, color: Colors.grey[400]!))),
      height: 40,
      width: double.infinity,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Expanded(
              flex: 3,
              child: Container(
                child: Text(
                  'Field Technicians',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
              )),
          ...timesHeader
        ],
      ),
    );
  }
}

/*
 *  NavBar For Tablet
 */

class NavBar extends StatefulWidget {
  final Function incremenDate;
  final Function decrementDate;
  final Function selectDate;
  final DateTime selectedDate;

  const NavBar(
      {Key? key,
      required this.selectDate,
      required this.selectedDate,
      required this.incremenDate,
      required this.decrementDate})
      : super(key: key);

  @override
  _NavBarState createState() => _NavBarState();
}

class _NavBarState extends State<NavBar> {
  late ScheduleProvider scheduleProvider;
  DateFormat textFormatter = DateFormat('yMMMMd');

  @override
  void initState() {
    super.initState();
    scheduleProvider = Provider.of<ScheduleProvider>(context, listen: false);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        padding: EdgeInsets.all(10),
        decoration: BoxDecoration(
            border:
                Border(bottom: BorderSide(width: 1, color: Colors.grey[300]!))),
        width: double.infinity,
        height: 60,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                SizedBox(width: 20),
                IconButton(
                    icon: Icon(Icons.date_range),
                    onPressed: () => this.widget.selectDate(context)),
                SizedBox(width: 20),
                IconButton(
                  icon: Icon(Icons.chevron_left),
                  onPressed: () => this.widget.decrementDate(),
                ),
                IconButton(
                  icon: Icon(Icons.chevron_right),
                  onPressed: () => this.widget.incremenDate(),
                ),
                SizedBox(width: 20),
                Text(textFormatter.format(this.widget.selectedDate)),
                SizedBox(width: 50),
                StatusKeyDropdown(),
              ],
            ),
            Row(
              children: [
                SizedBox(width: 20),
                Container(
                    padding: EdgeInsets.all(5),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey[400]!, width: 1),
                    ),
                    child: Icon(Icons.swap_horiz)),
                SizedBox(width: 10),
                Container(
                    padding: EdgeInsets.all(5),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey[400]!, width: 1),
                    ),
                    child: Icon(Icons.today)),
                Container(
                    padding: EdgeInsets.all(5),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey[400]!, width: 1),
                    ),
                    child: Icon(Icons.event_note)),
                Container(
                    padding: EdgeInsets.all(5),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey[400]!, width: 1),
                    ),
                    child: Icon(Icons.event)),
                SizedBox(width: 20),
              ],
            )
          ],
        ));
  }
}

/*
 *
 * Phone Layout
 *
 */

class PhoneLayout extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppTheme.green,
        title: Center(child: Text('Schedule')),
        leading: Builder(
          builder: (BuildContext context) {
            return IconButton(
              icon: const Icon(Icons.menu),
              onPressed: () {
                Scaffold.of(context).openDrawer();
              },
            );
          },
        ),
        actions: [SizedBox(width: 50)],
      ),
      drawer: Drawer(
        child: LeftDrawer(),
      ),
      body: Column(
        children: [
          Expanded(
              child: ListView(
            children: [
              ListTile(
                title: Text('Schedule #1'),
                onTap: () => Navigator.push(context,
                    MaterialPageRoute(builder: (context) => DetailedView())),
              ),
              Divider(height: 4),
              ListTile(
                title: Text('Schedule #2'),
                onTap: () => Navigator.push(context,
                    MaterialPageRoute(builder: (context) => DetailedView())),
              ),
              Divider(height: 4),
              ListTile(
                title: Text('Schedule #3'),
                onTap: () => Navigator.push(context,
                    MaterialPageRoute(builder: (context) => DetailedView())),
              ),
              Divider(height: 4),
              ListTile(
                title: Text('Schedule #4'),
                onTap: () => Navigator.push(context,
                    MaterialPageRoute(builder: (context) => DetailedView())),
              ),
              Divider(height: 4),
            ],
          )),
        ],
      ),
    );
  }
}

class DetailedView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppTheme.green,
      ),
      body: Center(
        child: Text('Schedule Data Here'),
      ),
    );
  }
}
